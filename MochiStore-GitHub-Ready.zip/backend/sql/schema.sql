CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS products (
 id BIGSERIAL PRIMARY KEY, sku TEXT NOT NULL UNIQUE, name TEXT NOT NULL, package_name TEXT NOT NULL,
 category TEXT NOT NULL DEFAULT 'Aplikasi Premium', price_idr BIGINT NOT NULL CHECK(price_idr >= 0),
 stock_mode TEXT NOT NULL DEFAULT 'manual' CHECK(stock_mode IN ('manual','supplier')),
 active BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS inventory_items (
 id BIGSERIAL PRIMARY KEY, sku TEXT NOT NULL REFERENCES products(sku) ON DELETE CASCADE,
 secret_value TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'available' CHECK(status IN ('available','reserved','delivered')),
 order_id UUID, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), delivered_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS inventory_available_idx ON inventory_items(sku,status,id);
CREATE TABLE IF NOT EXISTS orders (
 id BIGSERIAL PRIMARY KEY, public_id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(), sku TEXT NOT NULL REFERENCES products(sku),
 customer_email TEXT NOT NULL, amount_idr BIGINT NOT NULL CHECK(amount_idr > 0), payment_reference TEXT UNIQUE,
 payment_status TEXT NOT NULL DEFAULT 'pending' CHECK(payment_status IN ('pending','paid','failed','refunded')),
 fulfillment_status TEXT NOT NULL DEFAULT 'awaiting_payment' CHECK(fulfillment_status IN ('awaiting_payment','queued','delivered','failed','needs_review')),
 delivered_payload TEXT, idempotency_key TEXT NOT NULL UNIQUE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS orders_status_idx ON orders(fulfillment_status,created_at);
