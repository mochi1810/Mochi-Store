# Mochi Store backend starter

## Stock manual
1. Install Node.js 20+ and PostgreSQL on VPS.
2. Run `psql "$DATABASE_URL" -f sql/schema.sql` from this folder.
3. Copy `.env.example` to `.env`; set `DATABASE_URL`, `ADMIN_API_KEY`, and supplier variables privately.
4. Run `npm install` then `npm start`.
5. Serve `admin-stok.html` from the same origin as the API (or configure CORS/reverse proxy deliberately). Log in by entering `ADMIN_API_KEY`; register a product SKU and add one inventory item per line.

Admin endpoints require `x-admin-key`: `POST /api/admin/products`, `POST /api/admin/stock`, and `GET /api/admin/products`.

## Important current limitation
Checkout and payment webhook intentionally remain disabled. A real payment gateway has not yet been identified/configured, and no gateway-specific webhook signature/amount verification has been implemented. Do not accept real payment until the correct gateway adapter is added. After verified payment, backend must atomically lock one `inventory_items` row with status `available`, mark it `delivered`, and send the secret to the customer's email or order status page. Never deliver stock based on a client redirect or unverified webhook.

## BuzzerPanel
The supplier adapter remains unverified until the exact official API documentation/endpoint and request/response formats are supplied. Never expose `SMM_API_KEY` in frontend code.
