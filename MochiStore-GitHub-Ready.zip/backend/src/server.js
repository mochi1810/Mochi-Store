import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { Pool } from 'pg';
import { randomUUID, timingSafeEqual } from 'node:crypto';
import { smmRequest } from './smm-provider.js';

const app = express(); app.disable('x-powered-by'); app.use(helmet()); app.use(express.json({limit:'32kb'}));
app.use('/api/',rateLimit({windowMs:60_000,limit:90,standardHeaders:true,legacyHeaders:false}));
const pool=process.env.DATABASE_URL?new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.PGSSL==='true'?{rejectUnauthorized:true}:undefined}):null;
const dbRequired=(_req,res,next)=>{if(!pool)return res.status(503).json({ok:false,error:'Database belum dikonfigurasi.'});next();};
function adminOnly(req,res,next){const key=req.get('x-admin-key')||'';const expected=process.env.ADMIN_API_KEY||'';if(!expected||key.length!==expected.length||!timingSafeEqual(Buffer.from(key),Buffer.from(expected)))return res.status(401).json({ok:false,error:'Admin key tidak valid.'});next();}
app.get('/api/health',(_req,res)=>res.json({ok:true,service:'mochistore-backend',databaseConfigured:Boolean(pool),paymentConfigured:Boolean(process.env.PAYMENT_GATEWAY&&process.env.PAYMENT_SERVER_KEY),smmConfigured:Boolean(process.env.SMM_API_URL&&process.env.SMM_API_KEY)}));

// Admin: add stock as one code/login per line. Never expose this endpoint without admin key.
app.get('/api/admin/products',dbRequired,adminOnly,async(_req,res)=>{try{const r=await pool.query(`SELECT p.sku,p.name,p.package_name,p.price_idr,p.active,COUNT(i.id) FILTER(WHERE i.status='available')::int AS stock_available FROM products p LEFT JOIN inventory_items i ON i.sku=p.sku GROUP BY p.sku ORDER BY p.name,p.package_name`);res.json({ok:true,data:r.rows});}catch(e){res.status(500).json({ok:false,error:'Gagal mengambil produk.'});}});
app.post('/api/admin/products',dbRequired,adminOnly,async(req,res)=>{const {sku,name,packageName,category='Aplikasi Premium',price}=req.body||{};if(!sku||!name||!packageName||!Number.isSafeInteger(price)||price<=0)return res.status(400).json({ok:false,error:'sku, name, packageName, dan price positif wajib diisi.'});try{await pool.query(`INSERT INTO products(sku,name,package_name,category,price_idr) VALUES($1,$2,$3,$4,$5) ON CONFLICT(sku) DO UPDATE SET name=EXCLUDED.name,package_name=EXCLUDED.package_name,category=EXCLUDED.category,price_idr=EXCLUDED.price_idr,updated_at=NOW()`,[sku,name,packageName,category,price]);res.json({ok:true});}catch(e){res.status(500).json({ok:false,error:'Gagal menyimpan produk.'});}});
app.post('/api/admin/stock',dbRequired,adminOnly,async(req,res)=>{const {sku,items}=req.body||{};if(!sku||!Array.isArray(items)||!items.length||items.length>500||items.some(x=>typeof x!=='string'||!x.trim()||x.length>2000))return res.status(400).json({ok:false,error:'Isi sku dan items berupa array kode/login. Maksimal 500 item.'});const client=await pool.connect();try{await client.query('BEGIN');const p=await client.query('SELECT sku FROM products WHERE sku=$1 FOR UPDATE',[sku]);if(!p.rowCount){await client.query('ROLLBACK');return res.status(404).json({ok:false,error:'SKU produk belum terdaftar.'});}for(const item of items)await client.query('INSERT INTO inventory_items(sku,secret_value) VALUES($1,$2)',[sku,item.trim()]);await client.query('COMMIT');res.json({ok:true,added:items.length});}catch(e){await client.query('ROLLBACK');res.status(500).json({ok:false,error:'Stok gagal ditambahkan.'});}finally{client.release();}});

// Customer order route intentionally refuses checkout until a real gateway adapter is configured.
app.post('/api/orders',dbRequired,async(req,res)=>{if(!process.env.PAYMENT_GATEWAY||!process.env.PAYMENT_SERVER_KEY)return res.status(503).json({ok:false,error:'Pembayaran otomatis belum diaktifkan. Admin perlu mengonfigurasi payment gateway terlebih dahulu.'});res.status(501).json({ok:false,error:'Adapter gateway belum diimplementasikan. Jangan menerima pembayaran sampai webhook signature diverifikasi.'});});
// A gateway-specific webhook must verify its signature, amount, and order reference before calling fulfillment.
// Deliberately disabled to prevent forged payment notifications from releasing stock.
app.post('/api/payment/webhook',(_req,res)=>res.status(501).json({ok:false,error:'Webhook payment belum dikonfigurasi dan diverifikasi.'}));
app.get('/api/smm/services',async(_req,res)=>{try{const result=await smmRequest('services',{});res.json({ok:true,data:result});}catch(err){res.status(err.status||502).json({ok:false,error:err.publicMessage||'Provider request failed.'});}});
app.use((err,_req,res,_next)=>{console.error('[server-error]',err?.message||'unknown');res.status(500).json({ok:false,error:'Internal server error'});});
const port=Number(process.env.PORT||3000);app.listen(port,()=>console.log(`Mochi Store backend listening on ${port}`));
process.on('SIGTERM',async()=>{if(pool)await pool.end();process.exit(0);});
