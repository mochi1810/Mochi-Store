/**
 * Provider adapter deliberately fails closed until the account-specific API docs are checked.
 * Do not assume that a public blog's sample endpoint matches your account.
 */
export async function smmRequest(action, params = {}) {
  const endpoint = process.env.SMM_API_URL;
  const key = process.env.SMM_API_KEY;
  if (!endpoint || !key) {
    const e = new Error('SMM_API_URL and SMM_API_KEY are not configured.');
    e.status = 503; e.publicMessage = 'Supplier API is not configured yet.'; throw e;
  }
  let url;
  try { url = new URL(endpoint); } catch {
    const e = new Error('Invalid SMM_API_URL'); e.status = 500; e.publicMessage = 'Supplier API URL is invalid.'; throw e;
  }
  if (url.protocol !== 'https:') {
    const e = new Error('Supplier endpoint must use HTTPS'); e.status = 500; e.publicMessage = 'Supplier API must use HTTPS.'; throw e;
  }
  // FORMAT TODO: replace request body/auth fields only after checking official docs.
  // Current form is a common SMM pattern, NOT verified for this account.
  const body = new URLSearchParams({ key, action, ...Object.fromEntries(Object.entries(params).map(([k,v]) => [k, String(v)])) });
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body, signal: controller.signal, redirect: 'error' });
    const raw = await response.text();
    if (!response.ok) {
      const e = new Error(`Provider HTTP ${response.status}`); e.status = 502; e.publicMessage = 'Supplier API returned an error.'; throw e;
    }
    try { return JSON.parse(raw); } catch {
      const e = new Error('Supplier response was not JSON'); e.status = 502; e.publicMessage = 'Supplier response format is not supported.'; throw e;
    }
  } catch (err) {
    if (err.name === 'AbortError') { const e = new Error('Supplier request timed out'); e.status = 504; e.publicMessage = 'Supplier API timed out. No automatic retry was performed.'; throw e; }
    throw err;
  } finally { clearTimeout(timer); }
}
